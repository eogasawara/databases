create tablespace projetos DATAFILE 'projetos.dbf' SIZE 64M AUTOEXTEND ON;

CREATE USER projetos IDENTIFIED BY "RedLab7!" DEFAULT TABLESPACE projetos TEMPORARY TABLESPACE temp QUOTA UNLIMITED ON projetos;

grant create session to projetos;
grant alter session to projetos;
grant create cluster to projetos;
grant create database link to projetos;
grant create sequence to projetos;
grant create synonym to projetos;
grant create table to projetos;
grant create view to projetos;
grant create trigger to projetos;
grant create procedure to projetos;
grant select_catalog_role to projetos;
grant select any dictionary to projetos;

